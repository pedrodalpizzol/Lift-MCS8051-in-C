#include<reg52.h>

void serial_config();
void send_byte(char c);
void serial_send_string(char* dado);
void serial_read_string(char by);

//size of the buffer must be adjusted
char reception = 0;
char buff[5]= {0,0,0,0,0};
char k=0;
bit delayfinished=1;
char taux;
void serial_config(){
//setup timer 1
PCON = PCON | 0x80;
TMOD = 0x20;
TR1 = 1;
TL1 = 250;
TH1 = 250;
	
//setup serial
//SERIAL NO MODO 1 OPERANDO NO MODO 1
SCON=0x40;
REN=1;
EA = 1;
ES = 1;
}

void send_byte(char c){
	SBUF = c;
	while(~TI);
	TI=0;
}

void serial_send_string(char* dado){
	char i=0;
	while(*(dado+i)){
	send_byte(*(dado+i));
	i++;
	}

}
void serial_read_byte(void) interrupt 4{
	if (RI){
	buff[k]=SBUF;
	k++;
	if (k>2) 
		{
		buff[2] += '0';	
		k=0;
		reception=1;
		}
	RI=0;
	}
	
	
}
void counter10s (void) interrupt 4{
// aqui temos que configurar uma interrup��o que incrementa uma vari�vel taux
// de forma que quando ela representar 10s manda o delayfinished==1
	
if(delayfinished==0){ // s� cai nesse la�o caso se eu setar NA MAIN que � pra iniciar a contagem
taux++
	if(taux==x){ //sendo x o numero de itera��es necess�rias pra 10s
	delayfinished=1;// indica que passaram 10s
		taux=0; // zera t2 pra iniciar a pr�xima contagem s� quando zerarmos o delayfinished
	}
}	
}
// devemos configurar uma interrup��o para contar 10 segundos usando o timer2 (unico que sobrou)
// melhor jeito na minha opini�o � s� incrementar uma vari�vel e quando estourar 10 segundos levantar uma flag (delayfinished)
// da� a gente zera a flag l� no c�digo da main

//teria que ser assim, quando a gente recebe PS1 come�amos uma contagem e levamos o estado atual pra 0,
// quando a contagem terminar voltamos a verificar os estados dependendo da fila