


//must be called before the use of other functions of this header.
//It's also important to remind that it uses timer1 and it's interr. routine.
void serial_config();
//sends a single byte
void send_byte(char c);
//sends a string
void serial_send_string(char* dado);

extern char reception;
extern char buff[5];
extern bit delayfinished=1;