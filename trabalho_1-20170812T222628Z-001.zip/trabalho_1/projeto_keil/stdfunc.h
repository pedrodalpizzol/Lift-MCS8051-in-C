
//the delay is 100 microssends times the input
void delay(char us);
//must be called before the use of the delay(us) function
void setup_timer0();
char debounce(char pino);
char keyboardRead();