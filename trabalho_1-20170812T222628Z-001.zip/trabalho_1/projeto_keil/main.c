#include<reg52.h>
#include "serial.h"
#include "LCD.h"
#include "stdfunc.h"


main(){
	setup_timer0();
	serial_config();
	lcd_config();
	
	lcd_write_string("pedro");
	serial_send_string("pedro");
	
	while(1){
	if (reception){
	lcd_send_command(1);
	lcd_write_string(buff);
	serial_send_string(buff);
	reception=0;
	}

	delay(200);
	}
}

