
void lcd_config(void);
void lcd_data_write(void);
void lcd_send_command(char comm);
void lcd_write_data(char dado);
void lcd_write_string(char* dado);

//missing a 'set pointer' funcion
