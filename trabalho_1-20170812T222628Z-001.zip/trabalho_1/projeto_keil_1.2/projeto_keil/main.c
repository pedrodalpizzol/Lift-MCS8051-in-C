#include<reg52.h>
#include <string.h>
#include "serial.h"
#include "LCD.h"
#include "stdfunc.h"

sbit ledi1 = P1^0;
sbit lede1 = P1^3;
sbit ledi2 = P1^1;
sbit lede2 = P1^4;
sbit ledi3 = P1^2;
sbit lede3 = P1^5;

void serial_handle(void);
void key_handle(char key);
void queue_check(char floor);
void update_leds(void);
	
//control variables
char current_floor = 1;
bit emergency = 0;
char current_state = 0;
char people = 0;
char queue[3] = 0;


//routine variables
char RX_command[5] = '0';
char key;

main(){
	setup_timer0();
	serial_config();
	lcd_config();
	
	lcd_write_string("peter");
	lcd_send_command(0x01);
	while(1){
		genesis:
	lcd_write_string("iniciou");
	if(reception == 1){
	reception = 0;
	serial_handle();
	}
	key = keyboardRead();
	if (key != -1){
	key_handle(key);
	}
	
	if (people > 4){
		//sends emergency bit 'M' + 8
		send_byte('M');
		send_byte(8);
		goto genesis;
	}
	//if queue is empty
	if(queue[0]==0){
		current_state = 0;
		goto genesis;
	}
	if(current_floor - queue[0] > 0){
		current_state = 1;
		send_byte('M');
		send_byte(1);
	}
	if(current_floor - queue[0] < 0){
		current_state = 2;
		send_byte('M');
		send_byte(2);
	}
	if(current_floor - queue[0] == 0){
		current_state = 0;
	}
	update_leds();
	}
}

void serial_handle(void){
strcpy(RX_command,buff);
if(strcmp (RX_command,"PS0") == 0);
if(strcmp (RX_command,"PS1") == 0)
    if(current_state == 1){
        current_floor++;
	}
	if(current_floor == queue[1]){
		//rotate vector to the left
		queue[1]=queue[2];
		queue[2]=queue[3];
		queue[3]=0;
	}
    if(current_state == 2)
        current_floor--;
        if(current_floor == queue[1]){
		//rotate vector to the left
		queue[1]=queue[2];
		queue[2]=queue[3];
		queue[3]=0;
        }
if(strcmp (RX_command,"PAp") == 0)
    people++;
if(strcmp (RX_command,"PRp") == 0)
    people--;


}
void key_handle(char key){
	if(key==(0 | 3)){
	queue_check(1);
	}
	if(key==(1 | 4)){
	queue_check(2);
	}
	if(key==(2 | 5)){
	queue_check(3);
	}
}

void queue_check(char floor){
	if(floor!=(queue[0]|queue[1]|queue[2])){
	if(queue[0]==0){
	queue[0] = floor;
	return;
	}
	if(queue[1]==0){
	queue[1] = floor;
	return;
	}
	if(queue[2]==0){
	queue[2] = floor;
	return;
	}
	}

}

void update_leds(){
char u;
P1 = 0;
	for (u = 0; u = 2 ; u++){
		switch (queue[u]){
			case 1:
				ledi1 = 1;
				lede1 = 1;
				break;
			case 2:
				ledi2 = 1;
				lede2 = 1;
				break;
			case 3:
				ledi3 = 1;
				lede3 = 1;
				break;
	}
	}	

}
