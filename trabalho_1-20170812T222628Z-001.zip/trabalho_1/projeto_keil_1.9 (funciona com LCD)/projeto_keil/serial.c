#include<reg52.h>

void serial_config();
void send_byte(char c);
void serial_send_string(char* dado);
void serial_read_string(char by);

//size of the buffer must be adjusted
char reception = 0;
char buff[5]= {0,0,0,0,0};
char k=0;
void serial_config(){
//setup timer 1
PCON = PCON | 0x80;
TMOD = 0x20;
TR1 = 1;
TL1 = 250;
TH1 = 250;
	
//setup serial
//SERIAL NO MODO 1
SCON=0x40;
REN=1;
EA = 1;
ES = 1;
}

void send_byte(char c){
	SBUF = c;
	while(~TI);
	TI=0;
}

void serial_send_string(char* dado){
	char i=0;
	while(*(dado+i)){
	send_byte(*(dado+i));
	i++;
	}

}
void serial_read_byte(void) interrupt 4{
	if (RI){
	buff[k]=SBUF;
	k++;
	if (k>2) 
		{
		//buff[2] += '0';	
		k=0;
		reception=1;
		}
	RI=0;
	}
}