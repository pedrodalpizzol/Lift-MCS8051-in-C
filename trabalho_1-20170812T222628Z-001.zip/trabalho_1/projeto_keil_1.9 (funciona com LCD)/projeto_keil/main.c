#include<reg52.h>
#include <string.h>
#include "serial.h"
#include "LCD.h"
#include "stdfunc.h"

sbit ledi1 = P2^0;
sbit lede1 = P2^3;
sbit ledi2 = P2^1;
sbit lede2 = P2^4;
sbit ledi3 = P2^2;
sbit lede3 = P2^5;

void serial_handle(void);
void key_handle(char key);
void queue_check(char floor);
void update_leds(void);
void state_handle(void);
void rotate_and_stop(void);
void update_lcd(void);
void lcd_first_run(void);
//control variables
char current_floor = 1;
char current_state = 0;
char people = 0;
char queue[3] = 0;


//routine variables
char RX_command[5] = {0,0,0,0,0};
char eraser[5] = {0,0,0,0,0};
char key=-1;

main(){
	setup_timer0();
	serial_config();
	lcd_config();
	setup_timer2();
	lcd_send_command(0x01);
	lcd_first_run();

	while(1){
		genesis:
	if((reception == 1) | (key != -1) | (queue[0] != 0)){
	if(reception == 1){
	reception = 0;
	serial_handle();
	}
	rotate_and_stop();
	if(~d10s){
	state_handle();
	}
	}
	key = keyboardRead();
	
	if (key != -1){
	key_handle(key);
	
	}
	update_lcd();
	update_leds();
	if (people > 4){
		//sends emergency bit 'M' + 8
		current_state = 3;
		goto genesis;
	}
		if((current_floor - queue[0]) == current_floor){
		//parado
			current_state = 0;
		}
	if(~d10s){
		//if queue is empty
		if(queue[0]==0){
			goto genesis;
		}
		if((current_floor - queue[0]) > 0){
			//descendo
			current_state = 1;
		}
		if((current_floor - queue[0]) < 0){
			//subindo
			current_state = 2;
		}
	}
}
}

void serial_handle(void){

strcpy(RX_command,buff);

if(strcmp (RX_command,"PS0") == 0);
	
if(strcmp (RX_command,"PS1") == 0){
    if(current_state == 2){
        current_floor++;
	}
	if(current_state == 1){
        current_floor--;}

}

if(RX_command[0] == 'P'){
if(RX_command[1] == 'A'){
	people++;
}
if(RX_command[1] == 'R'){
	people--;
}
}
strcpy(RX_command,eraser);
strcpy(buff,eraser);
}
void key_handle(char key){
	if((key==0) | (key==3)){
	queue_check(1);
	}
	if((key==1) | (key==4)){
	queue_check(2);
	}
	if((key==2) | (key==5)){
	queue_check(3);
	}
}

void queue_check(char floor){
	if(floor!=(queue[0]|queue[1]|queue[2])){
	if(queue[0]==0){
	queue[0] = floor;
	return;
	}
	if(queue[1]==0){
	queue[1] = floor;
	return;
	}
	if(queue[2]==0){
	queue[2] = floor;
	return;
	}
	}

}

void update_leds(){
	
char u = 0;
P2 = 0xFF;
	for (u = 0; u < 3 ; u++){
		switch (queue[u]){
			case 1:
				ledi1 = 0;
				lede1 = 0;
				break;
			case 2:
				ledi2 = 0;
				lede2 = 0;
				break;
			case 3:
				ledi3 = 0;
				lede3 = 0;
				break;
	}
	}	

}
void state_handle(){
if (current_state == 0){
	send_byte('M');
	send_byte(0);
}
if (current_state == 1){
	send_byte('M');
	send_byte(2);
}
if (current_state == 2){
	send_byte('M');
	send_byte(1);
}
if (current_state == 3){
	send_byte('M');
	send_byte(8);
}
}

void rotate_and_stop(){
if(current_floor == queue[0]){
		//rotate vector to the left
		queue[0]=queue[1];
		queue[1]=queue[2];
		queue[2]=0;
		current_state = 0;
		d10s = 1;
		send_byte('M');
		send_byte(0);
	}
}

 void update_lcd(){
	lcd_set_pointer(14,1);
	lcd_write_data('0'+current_floor);
	lcd_set_pointer(14,2);
	lcd_write_data('0'+people);
}
void lcd_first_run(void){
	lcd_set_pointer(1,1);
	lcd_write_string("ANDAR ATUAL:");
	lcd_send_command(0xC0);
	lcd_set_pointer(1,2);
	lcd_write_string("NUM PESSOAS:");
}