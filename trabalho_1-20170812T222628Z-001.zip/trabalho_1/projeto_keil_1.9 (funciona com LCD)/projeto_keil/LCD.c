#include <reg52.h>
#include "stdfunc.h"

sbit EN = P3^7;
sbit RS = P3^6;
char place=0;

#define DATA_PORT P1
#define COMM_WRITE RS=0
#define WRITE RS=1
#define EN_H EN=1
#define EN_L EN=0



void lcd_config(void);
void lcd_data_write(void);
void lcd_send_command(char comm);
void lcd_write_data(char dado);
void lcd_write_string(char* dado);
void lcd_set_pointer(char x,char y);
void lcd_point_to_origin(void);

void lcd_write_string(char* dado){
	char i=0;
	while(*(dado+i)){
	lcd_write_data(*(dado+i));
	i++;
	}

}

void lcd_config(){
	//espera 15ms para inicializar o display
	delay(15);
	COMM_WRITE;
	//configura para 8 bit mode
	lcd_send_command(0x38);
	delay(1);
	//repete para que ele possa ler a parte alta do byte
	lcd_send_command(0x38);
	delay(1);
	//entry mode = 'no shift' e 'auto-increment'
	lcd_send_command(0x06);
	delay(1);
	//display on/off control 110d  sendo d posi��o do cursor desejada, come�a em d=0
	lcd_send_command(0x0C);
	delay(1);
	//display clear
	lcd_send_command(0x01);
	delay(16);
}

void lcd_data_write(){
	EN_H;
	delay(1);
	EN_L;
}

void lcd_send_command(char comm){
	DATA_PORT = comm;
	COMM_WRITE;
	lcd_data_write();
}

void lcd_write_data(char dado){
	//neste caso, o dado j� � o c�digo em ASCII que dever� ser escrito na porta
	DATA_PORT = dado;
	WRITE;
	lcd_data_write();
}
void lcd_set_pointer(char x,char y){
place = 0;
place = x;
place = place + (1 << 7);
y--;
place = place + (y << 6);
lcd_send_command (place);
}

void lcd_point_to_origin(){

lcd_send_command(2);

}