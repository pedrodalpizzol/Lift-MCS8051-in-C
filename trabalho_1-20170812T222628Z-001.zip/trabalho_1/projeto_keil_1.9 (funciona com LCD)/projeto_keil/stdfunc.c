#include <reg52.h>

#define BOUNCE 8
unsigned char t0;
int t2 = 0;
bit d10s = 0;

void delay(char us);
void setup_timer0();
char debounce(char pino);
char keyboardRead();
void setup_timer2();

void delay(char us){
	//delay of 100*us microsseconds
	t0=0;
	while (us != t0){
}
}

void timer0 (void) interrupt 1{
t0++;
TF0=0;
}

void timer2 (void) interrupt 5{
	if(d10s){
	t2++;
	}	
	if(t2==1000){
	t2=0;
	d10s = 0;
	}
TF2=0;
}

void setup_timer0(){
//configure timer 0 to set a flag at 100us
TMOD = 2;
TH0 = 163;
TL0 = 163;
EA = 1;
ET0 = 1;
TR0 = 1;
}

void setup_timer2(){
//setup timer 2
//configuration for 10ms overflow
T2CON = 0;
RCAP2H=0xDC;
RCAP2L=0x00;
TH2=RCAP2H;
TL2=RCAP2L;
EA=1;
ET2=1;
TR2=1;
}

char keyboardRead(){
	char j;
	for (j = 0 ; j <= 7 ; j ++){
	char mask = (1 << j);
		if ((~P0) & mask){
	
			if (debounce(mask)){
			return j;
			}
		}
	}
	return -1;
}


char debounce(char pino){
	
char count = 0;
char keyNow = 0;
char keyLast = 0;
	
	while(count != BOUNCE){
	delay(1);
	keyNow = (~P0) && pino;
		if (keyNow != keyLast){
		count = 0;
	}
	count ++;
	keyLast = keyNow;
	}
	
return keyLast;

}
