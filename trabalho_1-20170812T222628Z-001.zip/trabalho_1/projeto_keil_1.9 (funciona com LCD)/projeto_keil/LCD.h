
void lcd_config(void);
void lcd_data_write(void);
void lcd_send_command(char comm);
void lcd_write_data(char dado);
void lcd_write_string(char* dado);
void lcd_set_pointer(char x,char y);
void lcd_point_to_origin();

